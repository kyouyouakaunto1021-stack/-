import lzma
__doc__ = lzma.__doc__
del lzma

from lzma import *
